from flask import Flask, request, render_template, redirect, url_for, session, jsonify
import mysql.connector
from mysql.connector import Error
from datetime import datetime, time
import cv2
import numpy as np
import os

app = Flask(__name__)
app.secret_key = '3b0b9e8f9e1c4bfc9f8c7a2d8c0d1e6c'  # Use a strong, unique secret key

# Set allowed network prefix (for your specific Wi-Fi network)
ALLOWED_NETWORK_PREFIX = "192.168.93."  # Update to your Wi-Fi network prefix

# Function to check if the user's IP belongs to the allowed network
def validate_network(ip):
    return ip.startswith(ALLOWED_NETWORK_PREFIX)

# Function to validate user credentials against the database
def validate_credentials(roll_no, student_id):
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='attendance',
            user='root',
            password=''
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            query = "SELECT * FROM student_details WHERE roll_no = %s AND student_id = %s"
            cursor.execute(query, (roll_no, student_id))
            result = cursor.fetchone()
            return result
    except Error as e:
        print(f"Error: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
    return None

# Function to authenticate the captured face image
def authenticate_face(captured_image_path, roll_no):
    stored_image_path = f'face_img/{roll_no}.jpg'
    
    # Check if the stored image exists
    if not os.path.exists(stored_image_path):
        print(f"Stored image for roll number {roll_no} not found.")
        return False

    # Load the images
    captured_image = cv2.imread(captured_image_path)
    stored_image = cv2.imread(stored_image_path)

    if captured_image is None or stored_image is None:
        print("Error loading images for face recognition.")
        return False

    # Convert images to grayscale
    gray_captured = cv2.cvtColor(captured_image, cv2.COLOR_BGR2GRAY)
    gray_stored = cv2.cvtColor(stored_image, cv2.COLOR_BGR2GRAY)

    # Initialize face recognizer
    face_recognizer = cv2.face.LBPHFaceRecognizer_create()
    
    # Train the recognizer with the stored image
    face_recognizer.train([gray_stored], np.array([0]))

    # Predict the captured image
    label, confidence = face_recognizer.predict(gray_captured)

    # Return True if confidence is below a threshold (indicating a match)
    return confidence < 100  # Adjust threshold as needed

# Route for the login page
@app.route('/')
def wifi_page():
    return render_template('wifi.html')

# Route to handle login validation
@app.route('/submit-login', methods=['POST'])
def login():
    roll_no = request.form.get('rollno')
    student_id = request.form.get('student_id')
    user_ip = request.remote_addr

    if not validate_network(user_ip):
        return redirect(url_for('error_page'))

    user = validate_credentials(roll_no, student_id)

    if user:
        session['roll_no'] = roll_no
        session['student_id'] = student_id
        return redirect(url_for('success_page'))
    else:
        return redirect(url_for('error_page'))

# Route for the result page (successful login)
@app.route('/success')
def success_page():
    roll_no = session.get('roll_no')
    student_id = session.get('student_id')
    student_name = "Student_name"  # Replace with actual student name retrieval if available
    return render_template('result.html', roll_no=roll_no, student_id=student_id, student_name=student_name)

# Route for marking attendance
@app.route('/mark-attendance', methods=['POST'])
def mark_attendance():
    roll_no = session.get('roll_no')

    # Assume image_path is sent from the client-side (should be the path to the captured image)
    captured_image_path = request.json.get('image_path')  # Path to the captured image sent from the client

    if authenticate_face(captured_image_path, roll_no):
        current_time = datetime.now().time()

        if time(9, 30) <= current_time <= time(12, 0):
            status = 'present'
            timestamp = datetime.now()
            column_name = 'FN_status'
            timestamp_column = 'FN_timestamp'
        elif time(14, 0) <= current_time <= time(16, 0):
            status = 'present'
            timestamp = datetime.now()
            column_name = 'AN_status'
            timestamp_column = 'AN_timestamp'
        else:
            status = 'absent'
            timestamp = None
            column_name = 'AN_status'
            timestamp_column = 'AN_timestamp'

        try:
            connection = mysql.connector.connect(
                host='localhost',
                database='attendance',
                user='root',
                password=''
            )
            
            if connection.is_connected():
                cursor = connection.cursor()
                query = f"""
                UPDATE student_details 
                SET {column_name} = %s, {timestamp_column} = %s 
                WHERE roll_no = %s
                """
                cursor.execute(query, (status, timestamp, roll_no))
                connection.commit()

        except Error as e:
            print(f"Error: {e}")
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()

        return jsonify(success=True, message="Attendance marked successfully.")
    else:
        return jsonify(success=False, message="Face authentication failed."), 401  # Return 401 for failed authentication

# Route for the attendance success page
@app.route('/attendance-success')
def attendance_success_page():
    return render_template('attendance_success.html')  # Create this template

# Route for the error page (incorrect network or credentials)
@app.route('/error')
def error_page():
    return render_template('error.html')  # This will show error message

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, ssl_context=('C:\\Users\\praha\\OneDrive\\Desktop\\newatten\\cert\\ssl\\certs\\cert.pem', 'C:\\Users\\praha\\OneDrive\\Desktop\\newatten\\privatekey\\ssl\\private\\key.pem'))
